# SAN PEDRO OFERTAS

Proyecto inicial PWA para marketplace de todo Paraguay. Se puede publicar como sitio web y luego empaquetar como APK con Capacitor u otra herramienta Android.

## Incluye
- Navegación pública: cualquiera puede mirar publicaciones sin registrarse.
- Registro/inicio con Google y Facebook mediante Firebase Authentication.
- Publicaciones de vendedores con foto, precio, descripción, ciudad y WhatsApp.
- Perfil público del vendedor con foto, nombre, ciudad y WhatsApp.
- Comentarios y consultas solo para usuarios registrados.
- Botón de WhatsApp del vendedor en cada anuncio.
- Compartir publicaciones.
- Anuncios normales gratuitos y solicitudes de destacados:
  - 30 días: Gs. 30.000
  - 20 días: Gs. 20.000
  - 10 días: Gs. 10.000
  - 5 días: Gs. 5.000
- Comprobante de transferencia/giro y aprobación manual del administrador.
- Panel inicial de administración para aprobar anuncios, aprobar destacados, eliminar anuncios y suspender/reactivar perfiles.
- Contacto de administración: Juan Saucedo, WhatsApp 0984 36 35 98.
- Diseño adaptable a celulares y computadoras e instalable como PWA.

## Importante: aún requiere configuración
Este ZIP no contiene claves ni proyecto Firebase. Sin Firebase configurado, la página muestra solo publicaciones de demostración y los botones de acceso/publicación explican que falta conectar el servicio.

## Cómo probar en GitHub
1. Crear un repositorio NUEVO llamado `san-pedro-ofertas`. No usar ni sobrescribir el repositorio de BILLAR 8 PRO.
2. Extraer el ZIP y subir todos los archivos y carpetas a la raíz del repositorio.
3. En GitHub, abrir Settings → Pages y publicar desde la rama `main`, carpeta `/ (root)`.
4. Para datos reales, crear un proyecto Firebase y habilitar Authentication con Google y Facebook, Firestore Database y Storage.
5. Copiar los datos de configuración web de Firebase en `firebase-config.js`.
6. Publicar las reglas `firestore.rules` y `storage.rules` en Firebase.
7. Crear manualmente en Firestore la colección `admins` y un documento cuyo ID sea el UID de la cuenta que administrará la plataforma. No publiques ese UID ni concedas ese permiso a vendedores.
8. Probar con cuentas de prueba antes de anunciar el sitio.

## Configurar proveedores
En Firebase Console → Authentication → Sign-in method, habilitar Google y Facebook. Facebook requiere crear/configurar una app en Meta y registrar el OAuth redirect URI que Firebase indique. Agregar el dominio del sitio a Authorized domains.

## Colecciones Firestore previstas
- `users/{uid}`: perfil, foto, ciudad, WhatsApp y estado.
- `admins/{uid}`: documento que identifica al administrador.
- `listings/{listingId}`: anuncios y estado de aprobación.
- `listings/{listingId}/comments/{commentId}`: preguntas y comentarios.
- `featuredRequests/{requestId}`: duración, importe, comprobante y estado.
- `categories/{categoryId}`: categorías administrables.

## Precios de destacados
Los precios se guardan en la lógica de la aplicación según esta tabla: 30 días Gs. 30.000; 20 días Gs. 20.000; 10 días Gs. 10.000; 5 días Gs. 5.000. El administrador debe verificar el comprobante antes de aprobar.

## Límites que deben completarse antes de producción
- La pantalla de administración inicial permite aprobar/eliminar anuncios, aprobar solicitudes de destacados y suspender/reactivar perfiles. La gestión completa de categorías, moderación avanzada de comentarios y eliminación de archivos físicos debe agregarse y probarse antes del lanzamiento.
- Suspender un perfil bloquea su acceso lógico cuando la app consulta el perfil; eliminar definitivamente una cuenta de Firebase Authentication requiere una función backend segura (por ejemplo Cloud Functions/Admin SDK). No se puede borrar una cuenta de Auth desde el navegador de forma segura.
- Revisar las reglas de seguridad con pruebas en Firebase Emulator antes de aceptar usuarios reales. Las reglas son un punto de partida, no una auditoría de seguridad.
- La aprobación de pagos es manual. No se procesan pagos dentro de la app.
- Este starter no es todavía un APK nativo compilado. Primero se configura y prueba la web; luego se empaqueta para Android.

## Contacto
Juan Saucedo — WhatsApp 0984 36 35 98.
