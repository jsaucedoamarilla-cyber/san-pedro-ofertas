import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, doc, getDoc, getDocs, addDoc, setDoc, updateDoc, deleteDoc, query, where, orderBy, serverTimestamp, onSnapshot } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const configured = firebaseConfig.apiKey !== "PEGAR_API_KEY" && firebaseConfig.projectId !== "TU-PROYECTO";
let app, auth, db, storage, currentUser=null, currentProfile=null, allListings=[];
const ADMIN_WA = "595984363598";
const demoListings = [
  {id:"demo1",title:"Moto en venta",price:4500000,category:"Vehículos",city:"San Pedro del Ycuamandyyú",department:"San Pedro",sellerName:"Vendedor de ejemplo",photo:"https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=800",featured:true,description:"Publicación de muestra para ver el diseño.",whatsapp:"0984123456"},
  {id:"demo2",title:"Celular usado",price:850000,category:"Celulares",city:"Asunción",department:"Central",sellerName:"Comercio de ejemplo",photo:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800",featured:false,description:"Publicación de muestra para ver el diseño.",whatsapp:"0984123456"},
  {id:"demo3",title:"Juego de muebles",price:1200000,category:"Muebles",city:"Encarnación",department:"Itapúa",sellerName:"Vendedor de ejemplo",photo:"https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800",featured:false,description:"Publicación de muestra para ver el diseño.",whatsapp:"0984123456"},
  {id:"demo4",title:"Casa en alquiler",price:0,category:"Inmuebles",city:"Caaguazú",department:"Caaguazú",sellerName:"Inmobiliaria de ejemplo",photo:"https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800",featured:true,description:"Publicación de muestra para ver el diseño.",whatsapp:"0984123456"}
];
const $ = s => document.querySelector(s);
const money = n => n ? "Gs. "+Number(n).toLocaleString("es-PY") : "Consultar precio";
const cleanPhone = p => (p||"").replace(/\D/g,"").replace(/^0/,"595");
const escapeHtml = s => String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function show(id){const d=document.getElementById(id);if(d&&!d.open)d.showModal()}
function close(id){const d=document.getElementById(id);if(d?.open)d.close()}
function notice(id,msg){const el=document.getElementById(id);if(el)el.textContent=msg}
function isDemo(){return !configured}
function waLink(number,text="Hola, vi tu publicación en SAN PEDRO OFERTAS. ¿Sigue disponible?"){return `https://wa.me/${cleanPhone(number)}?text=${encodeURIComponent(text)}`}
async function upload(file,path){const r=ref(storage,path);await uploadBytes(r,file);return await getDownloadURL(r)}
function sampleCard(item){return `<article class="listing-card" data-id="${escapeHtml(item.id)}"><img class="listing-image" src="${escapeHtml(item.photo||"assets/icon.svg")}" alt="${escapeHtml(item.title)}"><div class="listing-body">${item.featured?'<span class="featured-tag">⭐ DESTACADO</span>':""}<h3>${escapeHtml(item.title)}</h3><div class="price">${money(item.price)}</div><div class="listing-meta">📍 ${escapeHtml(item.city||"Paraguay")} · ${escapeHtml(item.sellerName||"Vendedor")}</div></div></article>`}
function renderListings(){
  const search=$("#searchInput").value.trim().toLowerCase();
  const active=document.querySelector(".category.active")?.dataset.category||"Todas";
  const filtered=allListings.filter(x=>(active==="Todas"||x.category===active)&&(!search||`${x.title} ${x.description} ${x.city} ${x.category}`.toLowerCase().includes(search)));
  const featured=filtered.filter(x=>x.featured).sort((a,b)=>(b.featuredUntil||0)-(a.featuredUntil||0));
  $("#featuredGrid").innerHTML=featured.length?featured.map(sampleCard).join(""):'<div class="empty">Todavía no hay destacados activos.</div>';
  $("#listingGrid").innerHTML=filtered.length?filtered.map(sampleCard).join(""):'<div class="empty">No encontramos publicaciones con esos filtros.</div>';
}
function openDetail(id){
  const item=allListings.find(x=>x.id===id)||demoListings.find(x=>x.id===id);if(!item)return;
  const sellerPhoto=item.sellerPhoto||"assets/icon.svg";
  $("#detailContent").innerHTML=`<img class="detail-photo" src="${escapeHtml(item.photo)}" alt="${escapeHtml(item.title)}"><div style="padding-top:15px">${item.featured?'<span class="featured-tag">⭐ DESTACADO</span>':""}<h2>${escapeHtml(item.title)}</h2><div class="price">${money(item.price)}</div><p>${escapeHtml(item.description||"")}</p><p class="muted">📍 ${escapeHtml(item.city||"")} · ${escapeHtml(item.department||"")}</p><div class="profile-head"><img class="avatar" src="${escapeHtml(sellerPhoto)}" alt="Foto del vendedor"><div><b>${escapeHtml(item.sellerName||"Vendedor")}</b><div class="muted">Vendedor en SAN PEDRO OFERTAS</div></div></div><div class="detail-actions"><a class="primary" style="text-decoration:none" href="${waLink(item.whatsapp,`Hola, vi ${item.title} en SAN PEDRO OFERTAS. ¿Me das más información?`)}" target="_blank" rel="noopener">💬 Contactar por WhatsApp</a><button class="secondary" id="shareListing">↗ Compartir</button><button class="secondary" id="askComment">Comentar / preguntar</button></div><h3>Comentarios y consultas</h3><div id="commentsList"><p class="muted">Cargando comentarios…</p></div><form id="commentForm"><label>Tu comentario<textarea name="comment" required maxlength="500" rows="2" placeholder="Preguntá por el precio, disponibilidad…"></textarea></label><button class="primary" type="submit">Publicar comentario</button></form></div>`;
  $("#shareListing").onclick=async()=>{const share={title:item.title,text:`${item.title} - ${money(item.price)}`,url:location.href};if(navigator.share){try{await navigator.share(share)}catch{}}else{await navigator.clipboard?.writeText(`${share.text} ${share.url}`);alert("Enlace copiado (si tu navegador lo permite).")}};
  $("#askComment").onclick=()=>{if(!currentUser)show("authDialog");else $("#commentForm textarea").focus()};
  $("#commentForm").onsubmit=async e=>{e.preventDefault();if(!currentUser){show("authDialog");return}if(isDemo()){alert("Conectá Firebase para guardar comentarios.");return}const text=e.target.comment.value.trim();if(!text)return;await addDoc(collection(db,"listings",id,"comments"),{uid:currentUser.uid,author:currentProfile?.name||currentUser.displayName||"Usuario",text,createdAt:serverTimestamp(),status:"visible"});e.target.reset();loadComments(id)};
  show("detailDialog");loadComments(id);
}
async function loadComments(id){
  const box=$("#commentsList");if(!box)return;
  if(isDemo()||id.startsWith("demo")){box.innerHTML='<p class="muted">Sé el primero en consultar. Iniciá sesión para comentar.</p>';return}
  const q=query(collection(db,"listings",id,"comments"),orderBy("createdAt","asc"));
  onSnapshot(q,snap=>{const rows=snap.docs.map(d=>d.data()).filter(x=>x.status!=="deleted");box.innerHTML=rows.length?rows.map(x=>`<div class="comment"><b>${escapeHtml(x.author)}</b><br>${escapeHtml(x.text)}</div>`).join(""):'<p class="muted">Todavía no hay comentarios.</p>'},()=>box.innerHTML='<p class="muted">No se pudieron cargar los comentarios.</p>');
}
async function loadListings(){
  if(isDemo()){allListings=demoListings;renderListings();return}
  try{const q=query(collection(db,"listings"),where("status","==","approved"));const snap=await getDocs(q);const now=Date.now();allListings=snap.docs.map(d=>({id:d.id,...d.data()})).map(x=>({...x,featured:!!x.featured&&x.featuredUntil?.toMillis?.()>now,featuredUntil:x.featuredUntil?.toMillis?.()||0}));renderListings()}catch(e){console.error(e);allListings=[];renderListings()}
}
async function ensureProfile(user){
  const r=doc(db,"users",user.uid),s=await getDoc(r);
  if(!s.exists()){currentProfile={uid:user.uid,name:user.displayName||"Usuario",email:user.email||"",photo:user.photoURL||"",whatsapp:"",city:"",status:"active",createdAt:serverTimestamp()};await setDoc(r,currentProfile)}
  else currentProfile=s.data();
  if(currentProfile.status==="suspended"){await signOut(auth);alert("Esta cuenta está suspendida. Contactá al administrador.");return}
}
async function login(providerName){
  if(isDemo()){notice("authMessage","Modo demostración: configurá Firebase para habilitar el ingreso real.");return}
  try{const provider=providerName==="google"?new GoogleAuthProvider():new FacebookAuthProvider();const result=await signInWithPopup(auth,provider);await ensureProfile(result.user);close("authDialog");renderAccount()}catch(e){console.error(e);notice("authMessage",e.message||"No se pudo iniciar sesión.")}
}
function renderAccount(){
  $("#accountBtn").textContent=currentUser?"✓":"👤";
  if(currentUser)$("#accountBtn").title=currentProfile?.name||"Mi cuenta";
}
function openProfile(){
  if(!currentUser){show("authDialog");return}
  $("#profileContent").innerHTML=`<span class="eyebrow">MI CUENTA</span><h2>Perfil del vendedor</h2><div class="profile-head"><img class="avatar" src="${escapeHtml(currentProfile?.photo||currentUser.photoURL||"assets/icon.svg")}" alt="Foto de perfil"><div><b>${escapeHtml(currentProfile?.name||currentUser.displayName||"Usuario")}</b><p class="muted">${escapeHtml(currentProfile?.city||"Agregá tu ciudad")}</p></div></div><form id="profileForm"><label>Nombre visible<input name="name" required value="${escapeHtml(currentProfile?.name||currentUser.displayName||"")}"></label><label>Ciudad<input name="city" value="${escapeHtml(currentProfile?.city||"")}"></label><label>Tu WhatsApp para recibir consultas<input name="whatsapp" required value="${escapeHtml(currentProfile?.whatsapp||"")}" placeholder="0984 123 456"></label><label>Foto de perfil<input name="photo" type="file" accept="image/*"></label><button class="primary">Guardar perfil</button></form><button class="secondary" id="myFeatured" style="margin-top:12px">⭐ Solicitar publicación destacada</button><button class="secondary" id="logoutBtn" style="margin:12px 0 0 8px">Cerrar sesión</button><p class="fine-print">Tu nombre, foto y ciudad podrán mostrarse junto a tus publicaciones.</p>`;
  $("#profileForm").onsubmit=async e=>{e.preventDefault();const f=e.target;try{let photo=currentProfile?.photo||currentUser.photoURL||"";if(f.photo.files[0])photo=await upload(f.photo.files[0],`profiles/${currentUser.uid}/avatar`);currentProfile={...currentProfile,name:f.name.value.trim(),city:f.city.value.trim(),whatsapp:f.whatsapp.value.trim(),photo};await setDoc(doc(db,"users",currentUser.uid),currentProfile,{merge:true});alert("Perfil guardado.");close("profileDialog");}catch(err){alert(err.message)}};
  $("#myFeatured").onclick=()=>{close("profileDialog");openFeatured()};
  $("#logoutBtn").onclick=()=>signOut(auth);
  show("profileDialog");
}
async function openFeatured(){
  if(!currentUser){show("authDialog");return}
  if(isDemo()){alert("Conectá Firebase para solicitar un destacado.");return}
  const mine=allListings.filter(x=>x.ownerUid===currentUser.uid);
  $("#featuredListing").innerHTML=mine.map(x=>`<option value="${x.id}">${escapeHtml(x.title)}</option>`).join("");
  if(!mine.length){alert("Primero necesitás tener una publicación aprobada.");return}
  show("featuredDialog");
}
async function submitPublish(e){
  e.preventDefault();if(!currentUser){show("authDialog");return}if(isDemo()){notice("publishMessage","Conectá Firebase para enviar publicaciones reales.");return}
  const f=e.target,photo=f.photo.files[0];if(!photo)return;
  try{const url=await upload(photo,`listings/${currentUser.uid}/${Date.now()}-${photo.name}`);await addDoc(collection(db,"listings"),{title:f.title.value.trim(),price:Number(f.price.value)||0,category:f.category.value,description:f.description.value.trim(),department:f.department.value.trim(),city:f.city.value.trim(),whatsapp:f.whatsapp.value.trim(),photo:url,sellerName:currentProfile?.name||currentUser.displayName||"Vendedor",sellerPhoto:currentProfile?.photo||currentUser.photoURL||"",ownerUid:currentUser.uid,status:"pending",featured:false,createdAt:serverTimestamp()});notice("publishMessage","¡Enviado! Tu publicación queda pendiente de aprobación.");f.reset()}catch(err){notice("publishMessage",err.message)}
}
async function submitFeatured(e){
  e.preventDefault();if(!currentUser||isDemo())return;const f=e.target,file=f.receipt.files[0];try{const receipt=await upload(file,`receipts/${currentUser.uid}/${Date.now()}-${file.name}`);const days=Number(f.duration.value);await addDoc(collection(db,"featuredRequests"),{uid:currentUser.uid,listingId:f.listing.value,duration:days,amount:days*1000,receipt,status:"pending",createdAt:serverTimestamp()});notice("featuredMessage","Solicitud enviada. Esperá la aprobación del administrador.");}catch(err){notice("featuredMessage",err.message)}
}
async function openAdmin(){
  if(!currentUser){show("authDialog");return}
  if(isDemo()){alert("El panel real aparece al conectar Firebase y registrar al administrador.");return}
  const admin=await getDoc(doc(db,"admins",currentUser.uid));if(!admin.exists()){alert("Esta cuenta no tiene permisos de administrador.");return}
  const [pending,requests,users]=await Promise.all([getDocs(query(collection(db,"listings"),where("status","==","pending"))),getDocs(query(collection(db,"featuredRequests"),where("status","==","pending"))),getDocs(collection(db,"users"))]);
  const listingRows=pending.docs.map(d=>({id:d.id,...d.data()}));
  const requestRows=requests.docs.map(d=>({id:d.id,...d.data()}));
  const userRows=users.docs.map(d=>({id:d.id,...d.data()}));
  $("#adminContent").innerHTML=`<span class="eyebrow">CONTROL TOTAL</span><h2>Panel de administración</h2><p class="muted">Juan Saucedo · WhatsApp <a href="https://wa.me/${ADMIN_WA}" target="_blank">0984 36 35 98</a></p><h3>Publicaciones pendientes (${listingRows.length})</h3>${listingRows.map(x=>`<div class="admin-row"><span><b>${escapeHtml(x.title)}</b><br>${escapeHtml(x.city||"")}</span><span><button class="success" data-approve="${x.id}">Aprobar</button> <button class="danger" data-delete="${x.id}">Eliminar</button></span></div>`).join("")||'<p class="muted">No hay pendientes.</p>'}<h3>Solicitudes de destacados (${requestRows.length})</h3>${requestRows.map(x=>`<div class="admin-row"><span>${x.duration} días · ${money(x.amount)}<br><a href="${escapeHtml(x.receipt)}" target="_blank">Ver comprobante</a></span><button class="success" data-feature="${x.id}">Aprobar</button></div>`).join("")||'<p class="muted">No hay solicitudes.</p>'}<h3>Integrantes (${userRows.length})</h3>${userRows.map(x=>`<div class="admin-row"><span>${escapeHtml(x.name||x.email||x.id)}<br><small>${escapeHtml(x.city||"")}</small></span><button class="${x.status==="suspended"?"success":"danger"}" data-suspend="${x.id}" data-status="${x.status||"active"}">${x.status==="suspended"?"Reactivar":"Suspender"}</button></div>`).join("")||'<p class="muted">No hay integrantes.</p>'}`;
  $("#adminContent").querySelectorAll("[data-approve]").forEach(b=>b.onclick=async()=>{await updateDoc(doc(db,"listings",b.dataset.approve),{status:"approved",approvedAt:serverTimestamp()});openAdmin();loadListings()});
  $("#adminContent").querySelectorAll("[data-delete]").forEach(b=>b.onclick=async()=>{if(confirm("¿Eliminar esta publicación?")){await deleteDoc(doc(db,"listings",b.dataset.delete));openAdmin();loadListings()}});
  $("#adminContent").querySelectorAll("[data-feature]").forEach(b=>b.onclick=async()=>{const r=requestRows.find(x=>x.id===b.dataset.feature);const until=new Date(Date.now()+r.duration*86400000);await updateDoc(doc(db,"listings",r.listingId),{featured:true,featuredUntil:until,status:"approved"});await updateDoc(doc(db,"featuredRequests",r.id),{status:"approved",approvedAt:serverTimestamp()});openAdmin();loadListings()});
  $("#adminContent").querySelectorAll("[data-suspend]").forEach(b=>b.onclick=async()=>{const status=b.dataset.status==="suspended"?"active":"suspended";await updateDoc(doc(db,"users",b.dataset.suspend),{status});openAdmin()});
  show("adminDialog");
}
function setup(){
  document.addEventListener("click",e=>{const card=e.target.closest(".listing-card");if(card)openDetail(card.dataset.id)});
  document.querySelectorAll("[data-category]").forEach(b=>b.addEventListener("click",()=>{document.querySelectorAll(".category").forEach(x=>x.classList.remove("active"));b.classList.add("active");renderListings()}));
  $("#searchBtn").onclick=renderListings;$("#searchInput").addEventListener("keydown",e=>{if(e.key==="Enter")renderListings()});
  $("#clearFilters").onclick=()=>{$("#searchInput").value="";document.querySelectorAll(".category").forEach(x=>x.classList.toggle("active",x.dataset.category==="Todas"));renderListings()};
  $("#publishBtn").onclick=$("#navPublish").onclick=()=>{if(!currentUser)show("authDialog");else show("publishDialog")};
  $("#accountBtn").onclick=$("#navProfile").onclick=openProfile;$("#navAdmin").onclick=openAdmin;
  $("#googleLogin").onclick=()=>login("google");$("#facebookLogin").onclick=()=>login("facebook");
  $("#publishForm").onsubmit=submitPublish;$("#featuredForm").onsubmit=submitFeatured;
  document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>close(b.dataset.close));
  document.querySelectorAll(".modal").forEach(d=>d.addEventListener("click",e=>{if(e.target===d)d.close()}));
  if(configured){app=initializeApp(firebaseConfig);auth=getAuth(app);db=getFirestore(app);storage=getStorage(app);onAuthStateChanged(auth,async user=>{currentUser=user;if(user){try{await ensureProfile(user)}catch(e){console.error(e)}}else currentProfile=null;renderAccount()})}
  loadListings();
  if("serviceWorker" in navigator)navigator.serviceWorker.register("./sw.js").catch(console.warn);
}
setup();
