// Pegá aquí la configuración de tu proyecto Firebase.
// No pongas contraseñas ni claves privadas en este archivo.
export const firebaseConfig = {
  apiKey: "PEGAR_API_KEY",
  authDomain: "TU-PROYECTO.firebaseapp.com",
  projectId: "TU-PROYECTO",
  storageBucket: "TU-PROYECTO.appspot.com",
  messagingSenderId: "PEGAR_SENDER_ID",
  appId: "PEGAR_APP_ID"
};
