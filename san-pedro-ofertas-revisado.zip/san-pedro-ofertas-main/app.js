import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup, signInWithRedirect, getRedirectResult, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, doc, getDoc, getDocs, addDoc, setDoc, updateDoc, deleteDoc, query, where, orderBy, serverTimestamp, onSnapshot, increment } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject, listAll } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const configured = ["apiKey", "authDomain", "projectId", "storageBucket", "messagingSenderId", "appId"].every(k => typeof firebaseConfig[k] === "string" && firebaseConfig[k] && !firebaseConfig[k].includes("PEGAR_") && !firebaseConfig[k].includes("TU-PROYECTO"));
let app, auth, db, storage, currentUser = null, currentProfile = null, allListings = [], commentsUnsubscribe = null, authChoiceResolved = false;
const ADMIN_WA = "595984363598";
const FEATURED_PRICES = { 30: 30000, 20: 20000, 10: 10000, 3: 5000 };
const demoListings = [
  {id:"demo1",title:"Moto en venta",price:4500000,category:"Vehículos",city:"San Pedro del Ycuamandyyú",department:"San Pedro",sellerName:"Vendedor de ejemplo",photo:"https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=800",featured:true,description:"Publicación de muestra para ver el diseño.",whatsapp:"0984123456"},
  {id:"demo2",title:"Celular usado",price:850000,category:"Celulares",city:"Asunción",department:"Central",sellerName:"Comercio de ejemplo",photo:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=800",featured:false,description:"Publicación de muestra para ver el diseño.",whatsapp:"0984123456"},
  {id:"demo3",title:"Juego de muebles",price:1200000,category:"Muebles",city:"Encarnación",department:"Itapúa",sellerName:"Vendedor de ejemplo",photo:"https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=800",featured:false,description:"Publicación de muestra para ver el diseño.",whatsapp:"0984123456"},
  {id:"demo4",title:"Casa en alquiler",price:0,category:"Inmuebles",city:"Caaguazú",department:"Caaguazú",sellerName:"Inmobiliaria de ejemplo",photo:"https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800",featured:true,description:"Publicación de muestra para ver el diseño.",whatsapp:"0984123456"}
];
const $ = s => document.querySelector(s);
const money = n => n ? "Gs. " + Number(n).toLocaleString("es-PY") : "Consultar precio";
const cleanPhone = p => (p || "").replace(/\D/g, "").replace(/^0/, "595");
const escapeHtml = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const safeUrl = u => { try { const x = new URL(String(u || ""), location.href); return ["https:", "http:"].includes(x.protocol) ? x.href : ""; } catch { return ""; } };
async function compressImage(file, maxSide = 1600, quality = 0.85) {
  if (!file || !file.type.startsWith("image/") || file.type === "image/gif" || file.type === "image/svg+xml") return file;
  try {
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    const c = document.createElement("canvas"); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext("2d").drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise(r => c.toBlob(r, "image/jpeg", quality));
    if (!blob || blob.size >= file.size) return file;
    return new File([blob], file.name.replace(/\.[^.]+$/, "") + ".jpg", { type: "image/jpeg" });
  } catch { return file; }
}
const validPhone = p => cleanPhone(p).length >= 9;
const lock = (form, on) => form.querySelectorAll("button[type=submit]").forEach(b => b.disabled = on);
function show(id) { const d = document.getElementById(id); if (d && !d.open) d.showModal(); }
function close(id) { const d = document.getElementById(id); if (d?.open) d.close(); }
function notice(id, msg) { const el = document.getElementById(id); if (el) el.textContent = msg; }
function isDemo() { return !configured; }
function waLink(number, text = "Hola, vi tu publicación en SAN PEDRO OFERTAS. ¿Sigue disponible?") { return `https://wa.me/${cleanPhone(number)}?text=${encodeURIComponent(text)}`; }
async function upload(file, path) {
  if (!file) throw new Error("Seleccioná un archivo.");
  file = await compressImage(file);
  if (file.size > 8 * 1024 * 1024) throw new Error("El archivo no puede superar 8 MB.");
  const r = ref(storage, path); await uploadBytes(r, file); return getDownloadURL(r);
}
async function removeStorageUrl(url) { if (!url) return; try { await deleteObject(ref(storage, url)); } catch (e) { if (e.code !== "storage/object-not-found") console.warn("No se pudo borrar archivo:", e); } }
function visitorIdentity() {
  try {
    let id = localStorage.getItem("spofertas_visitor_id");
    let isNew = false;
    if (!id) {
      id = (globalThis.crypto?.randomUUID?.() || ("v-" + Date.now() + "-" + Math.random().toString(36).slice(2)));
      localStorage.setItem("spofertas_visitor_id", id);
      isNew = true;
    }
    return { id, isNew };
  } catch { return null; }
}
async function trackVisitor(user) {
  if (isDemo()) return;
  const identity = visitorIdentity();
  if (!identity) return;
  const visitorRef = doc(db, "anonymousVisitors", identity.id);
  try {
    if (user) {
      if (!identity.isNew) await updateDoc(visitorRef, { converted: true, lastSeen: serverTimestamp() });
    } else if (identity.isNew) {
      await setDoc(visitorRef, { firstSeen: serverTimestamp(), lastSeen: serverTimestamp(), converted: false });
    } else {
      await updateDoc(visitorRef, { lastSeen: serverTimestamp() });
    }
  } catch (e) { console.warn("No se pudo registrar la visita anónima:", e); }
}
const seenAuth = () => { try { return sessionStorage.getItem("sp_seen"); } catch { return null; } };
const markSeen = () => { try { sessionStorage.setItem("sp_seen", "1"); } catch {} };
async function isAdmin() { if (!currentUser || isDemo()) return false; const s = await getDoc(doc(db, "admins", currentUser.uid)); return s.exists(); }
function sampleCard(item) {
  return `<article class="listing-card" data-id="${escapeHtml(item.id)}"><img class="listing-image" src="${escapeHtml(safeUrl(item.photo) || "assets/icon.svg")}" alt="${escapeHtml(item.title)}" loading="lazy"><div class="listing-body">${item.featured ? '<span class="featured-tag">⭐ DESTACADO</span>' : ""}<h3>${escapeHtml(item.title)}</h3><div class="price">${money(item.price)}</div><div class="listing-meta">📍 ${escapeHtml(item.city || "Paraguay")} · ${escapeHtml(item.sellerName || "Vendedor")}</div><div class="listing-meta">👁️ ${Number(item.views||0)} visitas</div></div></article>`;
}
function renderListings() {
  const search = $("#searchInput").value.trim().toLowerCase();
  const active = document.querySelector(".category.active")?.dataset.category || "Todas";
  const filtered = allListings.filter(x => (active === "Todas" || x.category === active) && (!search || `${x.title} ${x.description} ${x.city} ${x.category}`.toLowerCase().includes(search)));
  const featured = filtered.filter(x => x.featured).sort((a, b) => (b.featuredUntil || 0) - (a.featuredUntil || 0));
  $("#featuredGrid").innerHTML = featured.length ? featured.map(sampleCard).join("") : '<div class="empty">Todavía no hay destacados activos.</div>';
  $("#listingGrid").innerHTML = filtered.length ? filtered.map(sampleCard).join("") : '<div class="empty">No encontramos publicaciones con esos filtros.</div>';
}
function openDetail(id) {
  const item = allListings.find(x => x.id === id) || demoListings.find(x => x.id === id); if (!item) return;
  const sellerPhoto = safeUrl(item.sellerPhoto) || "assets/icon.svg";
  $("#detailContent").innerHTML = `<img class="detail-photo" src="${escapeHtml(safeUrl(item.photo) || "assets/icon.svg")}" alt="${escapeHtml(item.title)}"><div style="padding-top:15px">${item.featured ? '<span class="featured-tag">⭐ DESTACADO</span>' : ""}<h2>${escapeHtml(item.title)}</h2><div class="price">${money(item.price)}</div><p>${escapeHtml(item.description || "")}</p><p class="muted">📍 ${escapeHtml(item.city || "")} · ${escapeHtml(item.department || "")}</p><div class="profile-head"><img class="avatar" src="${escapeHtml(sellerPhoto)}" alt="Foto del vendedor"><div><b>${escapeHtml(item.sellerName || "Vendedor")}</b><div class="muted">Vendedor en SAN PEDRO OFERTAS</div></div></div><div class="detail-actions"><a class="primary" style="text-decoration:none" href="${waLink(item.whatsapp, `Hola, vi ${item.title} en SAN PEDRO OFERTAS. ¿Me das más información?`)}" target="_blank" rel="noopener">💬 Contactar por WhatsApp</a><button class="secondary" id="shareListing">↗ Compartir</button><button class="secondary" id="askComment">Comentar / preguntar</button><button class="danger" id="reportListing">⚑ Denunciar</button></div><p class="muted" id="viewsCount">👁️ ${Number(item.views||0)} visitas</p><h3>Comentarios y consultas</h3><div id="commentsList"><p class="muted">Cargando comentarios…</p></div><form id="commentForm"><label>Tu comentario<textarea name="comment" required maxlength="500" rows="2" placeholder="Preguntá por el precio, disponibilidad…"></textarea></label><button class="primary" type="submit">Publicar comentario</button></form></div>`;
  if (!isDemo() && !id.startsWith("demo")) updateDoc(doc(db,"listings",id),{views:increment(1)}).then(()=>{item.views=Number(item.views||0)+1;const v=$("#viewsCount"); if(v) v.textContent=`👁️ ${item.views} visitas`;}).catch(e=>console.warn("No se pudo registrar visita",e));
  $("#reportListing").onclick = async () => { if(!currentUser){show("authDialog");return;} const reason=prompt("¿Por qué querés denunciar esta publicación? (Ej.: anuncio falso, precio engañoso, contenido inapropiado)"); if(!reason||!reason.trim())return; try{await addDoc(collection(db,"listingReports"),{listingId:id,listingTitle:item.title,uid:currentUser.uid,reason:reason.trim().slice(0,500),status:"pending",createdAt:serverTimestamp()});alert("Gracias. Tu denuncia fue enviada al administrador para revisión.");}catch(err){alert("No se pudo enviar la denuncia: "+err.message);} };
  $("#shareListing").onclick = async () => { const share = { title: item.title, text: `${item.title} - ${money(item.price)}`, url: location.origin + location.pathname + "#l=" + id }; if (navigator.share) { try { await navigator.share(share); } catch {} } else { try { await navigator.clipboard.writeText(`${share.text} ${share.url}`); alert("Enlace copiado."); } catch { alert("No se pudo copiar el enlace en este navegador."); } } };
  $("#askComment").onclick = () => { if (!currentUser) show("authDialog"); else $("#commentForm textarea").focus(); };
  $("#commentForm").onsubmit = async e => {
    e.preventDefault(); if (!currentUser) { show("authDialog"); return; }
    if (isDemo()) { alert("Conectá Firebase para guardar comentarios."); return; }
    const text = e.target.comment.value.trim(); if (!text) return;
    try { await addDoc(collection(db, "listings", id, "comments"), { uid: currentUser.uid, author: currentProfile?.name || currentUser.displayName || "Usuario", text, createdAt: serverTimestamp(), status: "visible" }); e.target.reset(); }
    catch (err) { alert(`No se pudo publicar el comentario: ${err.message}`); }
  };
  show("detailDialog"); loadComments(id);
}
async function loadComments(id) {
  const box = $("#commentsList"); if (!box) return;
  if (commentsUnsubscribe) { commentsUnsubscribe(); commentsUnsubscribe = null; }
  if (isDemo() || id.startsWith("demo")) { box.innerHTML = '<p class="muted">Sé el primero en consultar. Iniciá sesión para comentar.</p>'; return; }
  const admin = await isAdmin();
  const q = query(collection(db, "listings", id, "comments"), orderBy("createdAt", "asc"));
  commentsUnsubscribe = onSnapshot(q, snap => {
    const rows = snap.docs.filter(d => d.data().status !== "deleted"); const uid = currentUser?.uid;
    box.innerHTML = rows.length ? rows.map(d => `<div class="comment"><b>${escapeHtml(d.data().author || "Usuario")}</b><br>${escapeHtml(d.data().text || "")}${admin || (uid && d.data().uid === uid) ? ` <button class="danger comment-delete" data-comment-delete="${d.id}">Eliminar</button>` : ""}</div>`).join("") : '<p class="muted">Todavía no hay comentarios.</p>';
    box.querySelectorAll("[data-comment-delete]").forEach(b => b.onclick = async () => { if (confirm("¿Eliminar este comentario?")) { try { await deleteDoc(doc(db, "listings", id, "comments", b.dataset.commentDelete)); } catch (e) { alert(e.message); } } });
  }, err => { console.error(err); box.innerHTML = '<p class="muted">No se pudieron cargar los comentarios.</p>'; });
}
async function loadWantedRequests(){const grid=$("#wantedGrid");if(!grid)return;if(isDemo()){grid.innerHTML='<div class="empty">Conectá Firebase para publicar y consultar pedidos reales.</div>';return;}try{const snap=await getDocs(query(collection(db,"wantedRequests"),where("status","==","approved")));const now=Date.now();const rows=snap.docs.map(d=>({id:d.id,...d.data()})).filter(x=>!x.expiresAt||(x.expiresAt?.toMillis?.()||new Date(x.expiresAt).getTime())>now).sort((a,b)=>(b.createdAt?.toMillis?.()||0)-(a.createdAt?.toMillis?.()||0));grid.innerHTML=rows.length?rows.map(x=>'<article class="wanted-card" data-wanted="'+escapeHtml(x.id)+'"><div class="wanted-card-body"><span class="pill">🔎 BUSCO COMPRAR</span><h3>'+escapeHtml(x.title)+'</h3><p>'+escapeHtml(x.details||"")+'</p><div class="listing-meta">📍 '+escapeHtml(x.city||"")+', '+escapeHtml(x.department||"")+'</div><small>Publicado por '+escapeHtml(x.author||"Comprador")+'</small></div></article>').join(""):'<div class="empty">Todavía no hay pedidos de compra. ¡Sé el primero!</div>';}catch(e){console.error(e);grid.innerHTML='<div class="empty">No se pudieron cargar los pedidos.</div>';}}
async function openWantedDetail(id){if(isDemo()){alert("Conectá Firebase para ver pedidos y responder.");return;}try{const snap=await getDoc(doc(db,"wantedRequests",id));if(!snap.exists()||snap.data().status!=="approved")return;const item={id,...snap.data()};$("#wantedDetailContent").innerHTML='<span class="pill">🔎 BUSCO COMPRAR</span><h2>'+escapeHtml(item.title)+'</h2><p>'+escapeHtml(item.details||"")+'</p>'+(safeUrl(item.photo)?'<img class="detail-photo" src="'+escapeHtml(safeUrl(item.photo))+'" alt="Foto de referencia">':"")+'<p class="muted">📍 '+escapeHtml(item.city||"")+', '+escapeHtml(item.department||"")+' · '+escapeHtml(item.author||"Comprador")+'</p><div class="detail-actions"><a class="primary" style="text-decoration:none" href="'+waLink(item.whatsapp,"Hola, vi tu pedido en SAN PEDRO OFERTAS. Tengo una opción para ofrecerte.")+'" target="_blank" rel="noopener">💬 Contactar comprador</a></div><h3>Ofertas de vendedores</h3><div id="wantedReplies"><p class="muted">Cargando respuestas…</p></div><form id="wantedReplyForm"><label>Tu oferta o comentario<textarea name="text" required maxlength="600" rows="3" placeholder="Contá qué tenés para ofrecer, precio y detalles…"></textarea></label><label>Foto del producto (opcional)<input name="photo" type="file" accept="image/*"></label><button class="primary" type="submit">Enviar oferta</button></form>';const rs=await getDocs(collection(db,"wantedRequests",id,"replies"));const rows=rs.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.status!=="deleted").sort((a,b)=>(a.createdAt?.toMillis?.()||0)-(b.createdAt?.toMillis?.()||0));$("#wantedReplies").innerHTML=rows.length?rows.map(x=>'<div class="comment"><b>'+escapeHtml(x.author||"Vendedor")+'</b><p>'+escapeHtml(x.text||"") + '</p>'+(safeUrl(x.photo)?'<a href="'+escapeHtml(safeUrl(x.photo))+'" target="_blank" rel="noopener"><img class="reply-photo" src="'+escapeHtml(safeUrl(x.photo))+'" alt="Foto de oferta"></a>':"")+'</div>').join(""):'<p class="muted">Todavía no hay ofertas. ¡Podés ser el primero!</p>';$("#wantedReplyForm").onsubmit=async e=>{e.preventDefault();if(!currentUser){show("authDialog");return;}const text=e.target.elements.namedItem("text").value.trim(),file=e.target.elements.namedItem("photo").files[0];if(!text)return;try{let photo="";if(file)photo=await upload(file,"wanted-replies/"+currentUser.uid+"/"+Date.now()+"-"+file.name.replace(/[^\w.-]/g,"_"));await addDoc(collection(db,"wantedRequests",id,"replies"),{uid:currentUser.uid,author:currentProfile?.name||currentUser.displayName||"Vendedor",text,photo,status:"visible",createdAt:serverTimestamp()});await openWantedDetail(id);}catch(err){alert("No se pudo enviar la oferta: "+err.message);}};show("wantedDetailDialog");}catch(e){alert("No se pudo abrir el pedido: "+e.message);}}
async function submitWantedRequest(e){e.preventDefault();if(!currentUser){show("authDialog");return;}if(isDemo()){notice("wantedMessage","Conectá Firebase para publicar pedidos reales.");return;}const f=e.target,title=f.elements.namedItem("title").value.trim(),details=f.elements.namedItem("details").value.trim();if(!title||!details)return;if(!validPhone(f.elements.namedItem("whatsapp").value)){notice("wantedMessage","Ingresá un número de WhatsApp válido.");return;}lock(f,true);notice("wantedMessage","Enviando…");try{const file=f.elements.namedItem("photo").files[0];let photo="";if(file)photo=await upload(file,"wanted/"+currentUser.uid+"/"+Date.now()+"-"+file.name.replace(/[^\w.-]/g,"_"));await addDoc(collection(db,"wantedRequests"),{title,details,department:f.elements.namedItem("department").value.trim(),city:f.elements.namedItem("city").value.trim(),whatsapp:f.elements.namedItem("whatsapp").value.trim(),photo,uid:currentUser.uid,author:currentProfile?.name||currentUser.displayName||"Comprador",status:"pending",createdAt:serverTimestamp()});notice("wantedMessage","¡Pedido enviado! Aparecerá después de la aprobación del administrador.");f.reset();}catch(err){notice("wantedMessage","No se pudo enviar: "+err.message);}lock(f,false);}
async function loadListings() {
  if (isDemo()) { allListings = demoListings; renderListings(); return; }
  try {
    const snap = await getDocs(query(collection(db, "listings"), where("status", "==", "approved")));
    const now = Date.now();
    allListings = snap.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => (b.createdAt?.toMillis?.() || 0) - (a.createdAt?.toMillis?.() || 0)).filter(x => !x.expiresAt || (x.expiresAt?.toMillis?.() || new Date(x.expiresAt).getTime()) > now).map(x => ({ ...x, featured: !!x.featured && (x.featuredUntil?.toMillis?.() || new Date(x.featuredUntil || 0).getTime()) > now, featuredUntil: x.featuredUntil?.toMillis?.() || new Date(x.featuredUntil || 0).getTime() }));
    renderListings();
  } catch (e) { console.error(e); allListings = []; renderListings(); }
}
async function ensureProfile(user) {
  const r = doc(db, "users", user.uid), s = await getDoc(r);
  if (!s.exists()) {
    currentProfile = { uid: user.uid, name: user.displayName || "Usuario", email: user.email || "", photo: user.photoURL || "", whatsapp: "", city: "", status: "active", createdAt: serverTimestamp() };
    await setDoc(r, currentProfile);
  } else currentProfile = s.data();
  if (["suspended", "deleted"].includes(currentProfile.status)) { await signOut(auth); currentUser = null; currentProfile = null; alert("Esta cuenta no tiene acceso a la plataforma. Si necesitás ayuda, contactá al administrador."); }
}
async function login(providerName) {
  if (isDemo()) { notice("authMessage", "Modo demostración: falta conectar Firebase para habilitar el ingreso real."); return; }
  try {
    const provider = providerName === "google" ? new GoogleAuthProvider() : new FacebookAuthProvider();
    await signInWithPopup(auth, provider); authChoiceResolved = true; close("authDialog");
  } catch (e) {
    if (["auth/popup-blocked", "auth/operation-not-supported-in-this-environment"].includes(e.code)) {
      try { const provider = providerName === "google" ? new GoogleAuthProvider() : new FacebookAuthProvider(); await signInWithRedirect(auth, provider); return; } catch (redirectError) { e = redirectError; }
    }
    console.error(e); notice("authMessage", e.message || "No se pudo iniciar sesión.");
  }
}
function renderAccount() { $("#accountBtn").textContent = currentUser ? "✓" : "👤"; if (currentUser) $("#accountBtn").title = currentProfile?.name || "Mi cuenta"; }
function openProfile() {
  if (!currentUser) { show("authDialog"); return; }
  $("#profileContent").innerHTML = `<span class="eyebrow">MI CUENTA</span><h2>Perfil del vendedor</h2><div class="profile-head"><img class="avatar" src="${escapeHtml(safeUrl(currentProfile?.photo || currentUser.photoURL) || "assets/icon.svg")}" alt="Foto de perfil"><div><b>${escapeHtml(currentProfile?.name || currentUser.displayName || "Usuario")}</b><p class="muted">${escapeHtml(currentProfile?.city || "Agregá tu ciudad")}</p></div></div><form id="profileForm"><label>Nombre visible<input name="name" required maxlength="80" value="${escapeHtml(currentProfile?.name || currentUser.displayName || "")}"></label><label>Ciudad<input name="city" maxlength="80" value="${escapeHtml(currentProfile?.city || "")}"></label><label>Tu WhatsApp para recibir consultas<input name="whatsapp" required inputmode="tel" value="${escapeHtml(currentProfile?.whatsapp || "")}" placeholder="0984 123 456"></label><label>Foto de perfil<input name="photo" type="file" accept="image/*"></label><button class="primary">Guardar perfil</button></form><button class="secondary" id="myFeatured" style="margin-top:12px">⭐ Solicitar publicación destacada</button><button class="secondary" id="logoutBtn" style="margin:12px 0 0 8px">Cerrar sesión</button><div id="myListings"></div><div id="myWanted"></div><p class="fine-print">Tu nombre, foto y ciudad podrán mostrarse junto a tus publicaciones.</p>`;
  $("#profileForm").onsubmit = async e => { e.preventDefault(); const f = e.target; try { let photo = currentProfile?.photo || currentUser.photoURL || ""; if (f.elements.namedItem("photo").files[0]) photo = await upload(f.elements.namedItem("photo").files[0], `profiles/${currentUser.uid}/avatar`); const data = { name: f.elements.namedItem("name").value.trim(), city: f.elements.namedItem("city").value.trim(), whatsapp: f.elements.namedItem("whatsapp").value.trim(), photo }; if (!validPhone(data.whatsapp)) { alert("Ingresá un número de WhatsApp válido."); return; } await updateDoc(doc(db, "users", currentUser.uid), data); currentProfile = { ...currentProfile, ...data }; alert("Perfil guardado."); close("profileDialog"); } catch (err) { alert(err.message); } };
  $("#myFeatured").onclick = () => { close("profileDialog"); openFeatured(); };
  $("#logoutBtn").onclick = () => signOut(auth);
  show("profileDialog"); loadMyListings();
}
async function loadMyListings() {
  const box = $("#myListings"); if (!box || isDemo()) return;
  try {
    const s = await getDocs(query(collection(db, "listings"), where("ownerUid", "==", currentUser.uid)));
    const now = Date.now(), ST = { pending: "⏳ En revisión", approved: "✅ Publicada", rejected: "❌ Rechazada" };
    box.innerHTML = "<h3>Mis publicaciones</h3>" + (s.docs.map(d => { const x = d.data(), exp = x.expiresAt?.toMillis?.(); const st = x.status === "approved" && exp && exp < now ? "⌛ Vencida" : (ST[x.status] || x.status); return `<div class="admin-row"><span><b>${escapeHtml(x.title)}</b><br><small>${st}${x.rejectReason ? " · " + escapeHtml(x.rejectReason) : ""}</small></span><span class="btn-row">${st === "⌛ Vencida" ? `<button class="success" data-myrenew="${d.id}">Renovar 10 días</button>` : ""}<button class="danger" data-mydel="${d.id}">Eliminar</button></span></div>`; }).join("") || '<p class="muted">Todavía no publicaste nada.</p>');
    box.querySelectorAll("[data-myrenew]").forEach(b => b.onclick = async () => {
      try { await updateDoc(doc(db, "listings", b.dataset.myrenew), { expiresAt: new Date(Date.now() + 10 * 864e5 - 60000) }); await loadListings(); loadMyListings(); }
      catch (e) { alert("No se pudo renovar: " + e.message); }
    });
    box.querySelectorAll("[data-mydel]").forEach(b => b.onclick = async () => {
      if (!confirm("¿Eliminar tu publicación?")) return;
      try {
        const d = s.docs.find(x => x.id === b.dataset.mydel);
        await removeStorageUrl(d.data().photo);
        try { const cs = await getDocs(collection(db, "listings", d.id, "comments")); for (const c of cs.docs) await deleteDoc(c.ref); } catch {}
        await deleteDoc(d.ref); await loadListings(); loadMyListings();
      } catch (e) { alert(e.message); }
    });
  } catch (e) { console.warn(e); }
  loadMyWanted();
}
async function loadMyWanted() {
  const box = $("#myWanted"); if (!box || isDemo()) return;
  try {
    const s = await getDocs(query(collection(db, "wantedRequests"), where("uid", "==", currentUser.uid)));
    if (!s.docs.length) { box.innerHTML = ""; return; }
    const ST = { pending: "⏳ En revisión", approved: "✅ Publicado", rejected: "❌ Rechazado" }, now = Date.now();
    box.innerHTML = "<h3>Mis pedidos “Busco comprar”</h3>" + s.docs.map(d => { const x = d.data(), exp = x.expiresAt?.toMillis?.(); const st = x.status === "approved" && exp && exp < now ? "⌛ Vencido" : (ST[x.status] || x.status); return `<div class="admin-row"><span><b>${escapeHtml(x.title)}</b><br><small>${st}${x.rejectReason ? " · " + escapeHtml(x.rejectReason) : ""}</small></span><button class="danger" data-mywdel="${d.id}">Eliminar</button></div>`; }).join("");
    box.querySelectorAll("[data-mywdel]").forEach(b => b.onclick = async () => {
      if (!confirm("¿Eliminar tu pedido?")) return;
      try { await deleteDoc(doc(db, "wantedRequests", b.dataset.mywdel)); await loadWantedRequests(); loadMyWanted(); } catch (e) { alert(e.message); }
    });
  } catch (e) { console.warn(e); }
}
async function openFeatured() {
  if (!currentUser) { show("authDialog"); return; }
  if (isDemo()) { alert("Conectá Firebase para solicitar un destacado."); return; }
  const mine = allListings.filter(x => x.ownerUid === currentUser.uid);
  $("#featuredListing").innerHTML = mine.map(x => `<option value="${escapeHtml(x.id)}">${escapeHtml(x.title)}</option>`).join("");
  if (!mine.length) { alert("Primero necesitás tener una publicación aprobada."); return; }
  show("featuredDialog");
}
async function submitPublish(e) {
  e.preventDefault(); if (!currentUser) { show("authDialog"); return; } if (isDemo()) { notice("publishMessage", "Conectá Firebase para enviar publicaciones reales."); return; }
  const f = e.target, photo = f.elements.namedItem("photo").files[0]; if (!photo) return;
  if (!validPhone(f.elements.namedItem("whatsapp").value)) { notice("publishMessage", "Ingresá un número de WhatsApp válido."); return; }
  lock(f, true); notice("publishMessage", "Subiendo…");
  try {
    const url = await upload(photo, `listings/${currentUser.uid}/${Date.now()}-${photo.name.replace(/[^\w.-]/g, "_")}`);
    await addDoc(collection(db, "listings"), { title: f.elements.namedItem("title").value.trim(), price: Number(f.elements.namedItem("price").value) || 0, category: f.elements.namedItem("category").value, description: f.elements.namedItem("description").value.trim(), department: f.elements.namedItem("department").value.trim(), city: f.elements.namedItem("city").value.trim(), whatsapp: f.elements.namedItem("whatsapp").value.trim(), photo: url, sellerName: currentProfile?.name || currentUser.displayName || "Vendedor", sellerPhoto: currentProfile?.photo || currentUser.photoURL || "", ownerUid: currentUser.uid, status: "pending", featured: false, createdAt: serverTimestamp() });
    notice("publishMessage", "¡Enviado! Tu publicación queda pendiente de aprobación."); f.reset();
  } catch (err) { notice("publishMessage", err.message); }
  lock(f, false);
}
async function submitFeatured(e) {
  e.preventDefault(); if (!currentUser || isDemo()) return;
  const f = e.target, file = f.receipt.files[0], days = Number(f.duration.value), amount = FEATURED_PRICES[days];
  if (!file || !amount) { notice("featuredMessage", "Revisá la duración y adjuntá el comprobante."); return; }
  lock(f, true); notice("featuredMessage", "Subiendo comprobante…");
  try {
    const receipt = await upload(file, `receipts/${currentUser.uid}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`);
    await addDoc(collection(db, "featuredRequests"), { uid: currentUser.uid, listingId: f.listing.value, duration: days, amount, receipt, status: "pending", createdAt: serverTimestamp() });
    notice("featuredMessage", "Solicitud enviada. Esperá la aprobación del administrador."); f.reset();
  } catch (err) { notice("featuredMessage", err.message); }
  lock(f, false);
}
function openAdmin() { location.href = "admin.html"; }
function setup() {
  document.addEventListener("click", e => { const card = e.target.closest(".listing-card"); if (card) openDetail(card.dataset.id); });
  document.querySelectorAll("[data-category]").forEach(b => b.addEventListener("click", () => { document.querySelectorAll(".category").forEach(x => x.classList.remove("active")); b.classList.add("active"); renderListings(); }));
  $("#searchBtn").onclick = renderListings; $("#searchInput").addEventListener("keydown", e => { if (e.key === "Enter") renderListings(); });
  $("#clearFilters").onclick = () => { $("#searchInput").value = ""; document.querySelectorAll(".category").forEach(x => x.classList.toggle("active", x.dataset.category === "Todas")); renderListings(); };
  const openPublish = () => { if (!currentUser) { notice("authMessage", "Para publicar necesitás registrarte o iniciar sesión."); show("authDialog"); } else show("publishDialog"); };
  $("#publishBtn").onclick = $("#navPublish").onclick = openPublish;
  $("#accountBtn").onclick = $("#navProfile").onclick = openProfile;
  $("#navAdmin").onclick = openAdmin;
  $("#googleLogin").onclick = () => login("google"); $("#facebookLogin").onclick = () => login("facebook");
  $("#continueAccount").onclick = () => { authChoiceResolved = true; close("authDialog"); };
  $("#guestContinue").onclick = async () => { authChoiceResolved = true; markSeen(); if (currentUser) { try { await signOut(auth); } catch (e) { console.error("No se pudo cambiar a invitado:", e); } } close("authDialog"); };
  document.querySelectorAll("[data-view='home']").forEach(b => b.addEventListener("click", e => { e.preventDefault(); window.scrollTo({top:0,behavior:"smooth"}); }));
  document.querySelectorAll("[data-scroll]").forEach(b => b.addEventListener("click", () => { const target=document.getElementById(b.dataset.scroll); if(target) target.scrollIntoView({behavior:"smooth",block:"start"}); }));
  $("#publishForm").onsubmit = submitPublish; $("#featuredForm").onsubmit = submitFeatured; $("#wantedForm").onsubmit = submitWantedRequest;
  $("#wantedPublishBtn").onclick = () => { if (!currentUser) { notice("authMessage", "Para publicar un pedido de compra necesitás registrarte o iniciar sesión."); show("authDialog"); } else show("wantedDialog"); };
  $("#wantedGrid").addEventListener("click", e => { const card=e.target.closest("[data-wanted]"); if(card) openWantedDetail(card.dataset.wanted); });
  $("#authDialog").addEventListener("close", markSeen);
  $("#detailDialog").addEventListener("close", () => { if (commentsUnsubscribe) { commentsUnsubscribe(); commentsUnsubscribe = null; } });
  document.querySelectorAll("[data-close]").forEach(b => b.onclick = () => close(b.dataset.close));
  document.querySelectorAll(".modal").forEach(d => d.addEventListener("click", e => { if (e.target === d) d.close(); }));
  if (configured) {
    $("#demoNote")?.remove();
    app = initializeApp(firebaseConfig); auth = getAuth(app); db = getFirestore(app); storage = getStorage(app);
    getRedirectResult(auth).catch(e => { console.error(e); notice("authMessage", e.message); });
    onAuthStateChanged(auth, async user => {
      currentUser = user;
      if (user) {
        try { await ensureProfile(user); } catch (e) { console.error(e); }
      } else {
        currentProfile = null;
      }
      const continueButton = $("#continueAccount");
      if (continueButton) continueButton.hidden = !user;
      if (!authChoiceResolved && !user && !seenAuth()) {
        notice("authMessage", "Elegí cómo ingresar. Podés explorar como invitado; para publicar o comentar deberás registrarte.");
        show("authDialog");
      }
      await trackVisitor(currentUser);
      renderAccount();
      const adm = !!currentUser && await isAdmin().catch(() => false);
      $("#navAdmin").hidden = !adm; $("#topAdmin").hidden = !adm;
    });
  } else {
    notice("authMessage", "Elegí cómo ingresar. Podés explorar como invitado; para publicar o comentar deberás registrarte.");
    show("authDialog");
  }
  loadListings().then(() => { const m = location.hash.match(/^#l=(.+)$/); if (m) openDetail(decodeURIComponent(m[1])); }); loadWantedRequests();
  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(console.warn);
}
setup();
