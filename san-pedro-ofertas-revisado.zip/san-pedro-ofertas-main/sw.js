const CACHE = "san-pedro-ofertas-v6";
const CORE = ["./", "./index.html", "./styles.css", "./app.js", "./firebase-config.js", "./manifest.webmanifest", "./privacidad.html", "./assets/icon.svg", "./assets/icon-192.png"];
self.addEventListener("install", e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(CORE)).then(() => self.skipWaiting())));
self.addEventListener("activate", e => e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k.startsWith("san-pedro-ofertas-") && k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim())));
// Red primero (siempre código actualizado), caché como respaldo sin conexión.
self.addEventListener("fetch", e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== "GET" || u.origin !== self.location.origin) return;
  e.respondWith(fetch(r).then(res => { if (res.ok) { const c = res.clone(); caches.open(CACHE).then(ch => ch.put(r, c)); } return res; }).catch(() => caches.match(r).then(h => h || caches.match("./index.html"))));
});
