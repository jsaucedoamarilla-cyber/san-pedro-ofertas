import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth, GoogleAuthProvider, FacebookAuthProvider, signInWithPopup, signInWithRedirect, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore, collection, collectionGroup, doc, getDoc, getDocs, addDoc, updateDoc, deleteDoc, query, where, limit, Timestamp, serverTimestamp, getCountFromServer } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getStorage, ref, deleteObject, listAll } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const app = initializeApp(firebaseConfig), auth = getAuth(app), db = getFirestore(app), st = getStorage(app);
const $ = s => document.querySelector(s), DAY = 864e5, PAGE = 40;
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ms = t => t?.toMillis?.() || (t ? new Date(t).getTime() || 0 : 0);
const dt = t => ms(t) ? new Date(ms(t)).toLocaleString("es-PY", { dateStyle: "short", timeStyle: "short" }) : "—";
const gs = n => n ? "Gs. " + Number(n).toLocaleString("es-PY") : "Consultar";
const wa = p => "https://wa.me/" + String(p || "").replace(/\D/g, "").replace(/^0/, "595");
const lst = x => x.status === "approved" && ms(x.expiresAt) && ms(x.expiresAt) < Date.now() ? "expired" : (x.status || "active");
const isFeat = x => x.featured && ms(x.featuredUntil) > Date.now();
const LBL = { pending: "PENDIENTE", approved: "APROBADA", expired: "VENCIDA", rejected: "RECHAZADA", visible: "VISIBLE", reviewed: "REVISADA", active: "ACTIVO", suspended: "SUSPENDIDO", deleted: "ELIMINADO" };
const bd = s => `<span class="badge ${s}">${LBL[s] || esc(s)}</span>`;
const ord = a => [...a].sort((x, y) => ms(y.createdAt) - ms(x.createdAt));
let me, D = {}, S = { tab: "resumen", q: "", f: "all", n: PAGE, modal: null };

const L = id => D.listings.find(x => x.id === id) || {}, W = id => D.wanted.find(x => x.id === id) || {};
const U = id => D.users.find(x => x.id === id) || {}, F = id => D.feat.find(x => x.id === id) || {};
const UN = id => U(id).name || U(id).email || id || "—", LT = id => L(id).title || "(eliminada)";
const toast = (m, err) => { const t = $("#toast"); t.textContent = m; t.className = "toast show" + (err ? " err" : ""); clearTimeout(toast.k); toast.k = setTimeout(() => t.className = "toast", 3500); };
const busy = on => document.body.classList.toggle("busy", on);

/* ---------- Acceso ---------- */
const gate = h => { $("#gate").hidden = false; $("#shell").hidden = true; $("#gate").innerHTML = `<div class="gate-card">${h}</div>`; };
function gateLogin(msg = "") {
  gate(`<span class="eyebrow">ACCESO RESTRINGIDO</span><h2>Panel de administración</h2><p class="muted">Ingresá con la cuenta de administrador.</p><button class="btn primary" id="gG">G&nbsp; Ingresar con Google</button><button class="btn" id="gF">f&nbsp; Ingresar con Facebook</button><p class="muted" id="gm">${esc(msg)}</p>`);
  const go = P => async () => { try { await signInWithPopup(auth, new P()); } catch (e) { if (["auth/popup-blocked", "auth/operation-not-supported-in-this-environment"].includes(e.code)) return signInWithRedirect(auth, new P()); $("#gm").textContent = e.message; } };
  $("#gG").onclick = go(GoogleAuthProvider); $("#gF").onclick = go(FacebookAuthProvider);
}
function gateDenied(u, why) {
  gate(`<span class="eyebrow">SIN PERMISOS</span><h2>Esta cuenta no es administradora</h2><p class="muted">${esc(u.email || u.displayName || "")}${why ? "<br>" + esc(why) : ""}</p><p>Para habilitarla, en Firebase Console → Firestore creá la colección <code>admins</code> y un documento cuyo ID sea:</p><p><code>${esc(u.uid)}</code></p><button class="btn" id="gOut">Cerrar sesión</button><a class="btn" href="index.html" style="margin-top:10px">← Volver al sitio</a>`);
  $("#gOut").onclick = () => signOut(auth);
}
onAuthStateChanged(auth, async u => {
  me = u; if (!u) return gateLogin();
  try { const a = await getDoc(doc(db, "admins", u.uid)); if (!a.exists()) return gateDenied(u); }
  catch (e) { return gateDenied(u, "No se pudo verificar: " + e.message); }
  $("#gate").hidden = true; $("#shell").hidden = false;
  $("#me").innerHTML = `<b>${esc(u.displayName || "Administrador")}</b>${esc(u.email || "")}`;
  load();
});
$("#logoutBtn").onclick = () => signOut(auth);
$("#refreshBtn").onclick = () => load();

/* ---------- Datos ---------- */
async function load() {
  busy(true); const errs = [];
  const g = n => getDocs(collection(db, n)).then(s => s.docs.map(d => ({ id: d.id, ...d.data() }))).catch(e => { errs.push(n); return []; });
  const cg = n => getDocs(collectionGroup(db, n)).then(s => s.docs.map(d => ({ id: d.id, path: d.ref.path, parent: d.ref.parent.parent.id, ...d.data() }))).catch(e => { errs.push(n + " (reglas)"); return []; });
  const av = collection(db, "anonymousVisitors"), cnt = q => getCountFromServer(q).then(s => s.data().count).catch(() => { errs.push("visitantes"); return 0; });
  const [users, listings, wanted, feat, reports, logs, admins, comments, replies, vTot, vAnon, vis] = await Promise.all([
    g("users"), g("listings"), g("wantedRequests"), g("featuredRequests"), g("listingReports"), g("adminLogs"), g("admins"), cg("comments"), cg("replies"),
    cnt(av), cnt(query(av, where("converted", "==", false))),
    getDocs(query(av, where("firstSeen", ">=", Timestamp.fromMillis(Date.now() - 30 * DAY)), limit(3000))).then(s => s.docs.map(d => ({ id: d.id, ...d.data() }))).catch(() => [])
  ]);
  D = { users, listings, wanted, feat, reports, logs, admins, comments, replies, vTot, vAnon, vis };
  $("#banner").innerHTML = errs.length ? `<div class="warn">⚠ No se pudieron leer: <b>${[...new Set(errs)].join(", ")}</b>. Publicá las reglas actualizadas (<code>firebase deploy --only firestore:rules,storage</code>) y recargá.</div>` : "";
  $("#lastSync").textContent = "Actualizado " + new Date().toLocaleTimeString("es-PY");
  busy(false); render(); if (S.modal) openModal(S.modal);
}

/* ---------- Render ---------- */
const NAV = [["resumen", "📊", "Resumen"], ["listings", "🛍️", "Publicaciones"], ["wanted", "🔎", "Busco comprar"], ["feat", "⭐", "Destacados"], ["comments", "💬", "Comentarios"], ["reports", "⚑", "Denuncias"], ["users", "👥", "Usuarios"], ["visitors", "👀", "Visitantes"], ["logs", "📜", "Actividad"], ["settings", "⚙", "Exportar y ajustes"]];
const pend = () => ({ listings: D.listings.filter(x => x.status === "pending").length, wanted: D.wanted.filter(x => x.status === "pending").length, feat: D.feat.filter(x => x.status === "pending").length, reports: D.reports.filter(x => x.status !== "reviewed").length });
function render() {
  const p = pend();
  $("#nav").innerHTML = NAV.map(([k, i, l]) => `<button data-tab="${k}" class="${S.tab === k ? "active" : ""}"><span class="ico">${i}</span>${l}${p[k] ? `<span class="badge-n">${p[k]}</span>` : ""}</button>`).join("");
  $("#viewTitle").textContent = NAV.find(n => n[0] === S.tab)[2];
  if (T[S.tab]) { listShell(); fill(); } else $("#main").innerHTML = V[S.tab]();
}
const go = t => { S.tab = t; S.q = ""; S.f = "all"; S.n = PAGE; render(); scrollTo(0, 0); };

const btn = (a, id, txt, cls = "", c = "", path = "") => `<button class="btn sm ${cls}" data-a="${a}" data-id="${esc(id)}"${path ? ` data-path="${esc(path)}"` : ""}${c ? ` data-c="${esc(c)}"` : ""}>${txt}</button>`;
const open = (k, txt = "Ver detalle") => `<button class="btn sm" data-open="${esc(k)}">${txt}</button>`;
const img = (s, c = "thumb") => `<img class="${c}" src="${esc(s || "assets/icon.svg")}" loading="lazy" alt="" onerror="this.style.visibility='hidden'">`;

const lActs = x => { const s = lst(x); return (s !== "approved" ? btn("L:approve", x.id, "✓ Aprobar", "ok") : "") + (s === "pending" ? btn("L:reject", x.id, "✕ Rechazar", "warn") : "") + btn("L:del", x.id, "🗑", "bad", "¿Eliminar definitivamente esta publicación, su foto y sus comentarios?"); };
const rL = x => `<div class="row ${["expired", "rejected"].includes(lst(x)) ? "dim" : ""}">${img(x.photo)}<div class="row-main"><div class="row-title">${esc(x.title)} ${bd(lst(x))}${isFeat(x) ? '<span class="badge feat">⭐ DESTACADA</span>' : ""}</div><div class="row-sub">${gs(x.price)} · ${esc(x.category)} · 📍 ${esc(x.city)}, ${esc(x.department)}<br>👤 ${esc(x.sellerName)} · 👁️ ${x.views || 0} · Creada ${dt(x.createdAt)} · Vence ${dt(x.expiresAt)}</div></div><div class="row-actions">${open("L:" + x.id)}${lActs(x)}</div></div>`;
const wActs = x => (lst(x) !== "approved" ? btn("W:approve", x.id, "✓ Aprobar", "ok") : "") + (lst(x) === "pending" ? btn("W:reject", x.id, "✕ Rechazar", "warn") : "") + btn("W:del", x.id, "🗑", "bad", "¿Eliminar este pedido y todas sus respuestas?");
const rW = x => `<div class="row ${x.photo ? "" : "no-thumb"} ${["expired", "rejected"].includes(lst(x)) ? "dim" : ""}">${x.photo ? img(x.photo) : ""}<div class="row-main"><div class="row-title">🔎 ${esc(x.title)} ${bd(lst(x))}</div><div class="row-sub">${esc((x.details || "").slice(0, 160))}<br>👤 ${esc(x.author)} · 📍 ${esc(x.city)}, ${esc(x.department)} · 💬 ${D.replies.filter(r => r.parent === x.id).length} respuestas · ${dt(x.createdAt)}</div></div><div class="row-actions">${open("W:" + x.id)}${wActs(x)}</div></div>`;
const rF = x => `<div class="row no-thumb"><div class="row-main"><div class="row-title">⭐ ${esc(LT(x.listingId))} ${bd(x.status)}</div><div class="row-sub">${x.duration} días · ${gs(x.amount)} · 👤 ${esc(UN(x.uid))} · ${dt(x.createdAt)}${x.rejectReason ? "<br>Motivo: " + esc(x.rejectReason) : ""}<br><a href="${esc(x.receipt)}" target="_blank" rel="noopener">📎 Ver comprobante</a></div></div><div class="row-actions">${x.status === "pending" ? btn("F:ok", x.id, "✓ Aprobar y destacar", "ok", "¿Verificaste el comprobante? Se destacará la publicación.") + btn("F:no", x.id, "✕ Rechazar", "warn") : ""}${L(x.listingId).id ? open("L:" + x.listingId, "Ver publicación") : ""}</div></div>`;
const rC = x => `<div class="row no-thumb"><div class="row-main"><div class="row-title"><span class="badge">${x.type === "reply" ? "RESPUESTA" : "COMENTARIO"}</span> ${esc(x.author)}</div><div class="row-sub">${esc(x.text)}${x.photo ? `<a href="${esc(x.photo)}" target="_blank" rel="noopener"><img class="reply-photo" src="${esc(x.photo)}" alt=""></a>` : ""}<br>En: ${esc(x.type === "reply" ? W(x.parent).title : LT(x.parent)) || "(eliminado)"} · ${dt(x.createdAt)}</div></div><div class="row-actions">${btn("C:del", x.id, "🗑 Eliminar", "bad", "¿Eliminar este mensaje?", x.path)}</div></div>`;
const rR = x => `<div class="row no-thumb ${x.status === "reviewed" ? "dim" : ""}"><div class="row-main"><div class="row-title">⚑ ${esc(x.listingTitle || LT(x.listingId))} ${bd(x.status === "reviewed" ? "reviewed" : "pending")}</div><div class="row-sub">“${esc(x.reason)}”<br>Denunciante: ${esc(UN(x.uid))} · ${dt(x.createdAt)}</div></div><div class="row-actions">${L(x.listingId).id ? open("L:" + x.listingId, "Ver publicación") + btn("R:sus", x.id, "Suspender dueño", "warn", "¿Suspender al dueño de la publicación?") + btn("R:dellisting", x.id, "Eliminar publicación", "bad", "¿Eliminar la publicación denunciada?") : ""}${x.status !== "reviewed" ? btn("R:ok", x.id, "✓ Revisada", "ok") : ""}</div></div>`;
const rU = x => { const s = x.status || "active", mine = x.id === me.uid; return `<div class="row ${s === "deleted" ? "dim" : ""}">${img(x.photo, "avatar")}<div class="row-main"><div class="row-title">${esc(x.name || "Sin nombre")} ${bd(s)}${D.admins.some(a => a.id === x.id) ? '<span class="badge admin">ADMIN</span>' : ""}</div><div class="row-sub">${esc(x.email || "—")} · ${esc(x.whatsapp || "sin WhatsApp")} · 📍 ${esc(x.city || "—")}<br>Registro ${dt(x.createdAt)} · 🛍️ ${D.listings.filter(l => l.ownerUid === x.id).length} · 🔎 ${D.wanted.filter(w => w.uid === x.id).length} · 💬 ${[...D.comments, ...D.replies].filter(c => c.uid === x.id).length}</div></div><div class="row-actions">${open("U:" + x.id)}${!mine && s !== "deleted" ? btn("U:sus", x.id, s === "suspended" ? "Reactivar" : "Suspender", s === "suspended" ? "ok" : "warn") + btn("U:del", x.id, "🗑 Eliminar datos", "bad", "¿Eliminar al integrante y TODOS sus datos, fotos, anuncios y comprobantes? No se puede deshacer.") : ""}</div></div>`; };

const ST = [["all", "Todos"], ["pending", "Pendientes"], ["approved", "Aprobados"], ["rejected", "Rechazados"]];
const T = {
  listings: { f: [["all", "Todas"], ["pending", "Pendientes"], ["approved", "Aprobadas"], ["expired", "Vencidas"], ["rejected", "Rechazadas"], ["feat", "Destacadas"]], items: () => D.listings, keep: (x, f) => f === "all" || (f === "feat" ? isFeat(x) : lst(x) === f), text: x => [x.title, x.description, x.city, x.department, x.category, x.sellerName, x.whatsapp, x.ownerUid], row: rL },
  wanted: { f: [["all", "Todos"], ["pending", "Pendientes"], ["approved", "Aprobados"], ["expired", "Vencidos"], ["rejected", "Rechazados"]], items: () => D.wanted, keep: (x, f) => f === "all" || lst(x) === f, text: x => [x.title, x.details, x.city, x.author, x.whatsapp, x.uid], row: rW },
  feat: { f: ST, items: () => D.feat, keep: (x, f) => f === "all" || x.status === f, text: x => [LT(x.listingId), UN(x.uid), x.status], row: rF },
  comments: { f: [["all", "Todos"], ["comment", "Comentarios"], ["reply", "Respuestas"]], items: () => [...D.comments.map(c => ({ ...c, type: "comment" })), ...D.replies.map(c => ({ ...c, type: "reply" }))], keep: (x, f) => f === "all" || x.type === f, text: x => [x.text, x.author, x.uid], row: rC },
  reports: { f: [["all", "Todas"], ["pending", "Pendientes"], ["reviewed", "Revisadas"]], items: () => D.reports, keep: (x, f) => f === "all" || (f === "reviewed") === (x.status === "reviewed"), text: x => [x.listingTitle, x.reason, UN(x.uid)], row: rR },
  users: { f: [["all", "Todos"], ["active", "Activos"], ["suspended", "Suspendidos"], ["deleted", "Eliminados"]], items: () => D.users, keep: (x, f) => f === "all" ? x.status !== "deleted" : (x.status || "active") === f, text: x => [x.name, x.email, x.whatsapp, x.city, x.id], row: rU }
};
function listShell() {
  const c = T[S.tab];
  $("#main").innerHTML = `<div class="toolbar"><input type="search" id="q" placeholder="🔎 Buscar…" value="${esc(S.q)}"><select id="f">${c.f.map(([k, l]) => `<option value="${k}" ${S.f === k ? "selected" : ""}>${l}</option>`).join("")}</select><button class="btn" data-exp="${S.tab}">⬇ CSV</button><span class="count" id="cnt"></span></div><div class="rows" id="list"></div><div class="more" id="more"></div>`;
  $("#q").oninput = e => { S.q = e.target.value.toLowerCase(); S.n = PAGE; fill(); };
  $("#f").onchange = e => { S.f = e.target.value; S.n = PAGE; fill(); };
}
function fill() {
  const c = T[S.tab], all = ord(c.items()).filter(x => c.keep(x, S.f) && (!S.q || c.text(x).join(" ").toLowerCase().includes(S.q)));
  $("#list").innerHTML = all.slice(0, S.n).map(c.row).join("") || '<div class="empty">No hay resultados.</div>';
  $("#cnt").textContent = all.length + " resultado" + (all.length === 1 ? "" : "s");
  $("#more").innerHTML = all.length > S.n ? `<button class="btn" data-more>Mostrar más (${all.length - S.n})</button>` : "";
}

/* ---------- Gráficos y vistas simples ---------- */
const daily = (rows, f) => { const a = Array(30).fill(0), t0 = new Date().setHours(0, 0, 0, 0) - 29 * DAY; rows.forEach(r => { const d = Math.floor((ms(r[f]) - t0) / DAY); if (d >= 0 && d < 30) a[d]++; }); return a; };
const chart = a => { const m = Math.max(1, ...a), w = 300 / a.length; return `<svg class="chart" viewBox="0 0 300 112">${a.map((v, i) => `<rect x="${i * w + 1}" y="${95 - v / m * 85}" width="${w - 2}" height="${v / m * 85}" rx="2" fill="#1769aa"><title>${v}</title></rect>`).join("")}<text x="0" y="109">hace 30 días</text><text x="300" y="109" text-anchor="end">hoy · máx. ${m}</text></svg>`; };
const cc = (t, a) => `<div class="card"><h3>${t} <span class="muted">· ${a.reduce((s, v) => s + v, 0)} en 30 días</span></h3>${chart(a)}</div>`;
const hb = (rows) => { const m = Math.max(1, ...rows.map(r => r[1])); return rows.map(([l, v]) => `<div class="hbar"><span title="${esc(l)}">${esc(l)}</span><div class="track"><i style="width:${v / m * 100}%"></i></div><b>${v}</b></div>`).join("") || '<p class="muted">Sin datos.</p>'; };
const top = (arr, f, n = 6) => Object.entries(arr.reduce((o, x) => { const k = x[f] || "—"; o[k] = (o[k] || 0) + 1; return o; }, {})).sort((a, b) => b[1] - a[1]).slice(0, n);
const kpi = (i, l, v, s = "", tab = "") => `<${tab ? `button data-tab="${tab}"` : "div"} class="kpi"><span class="k-top">${i} ${l}</span><strong>${v}</strong><small>${s}</small></${tab ? "button" : "div"}>`;

const V = {
  resumen() {
    const p = pend(), lc = s => D.listings.filter(x => lst(x) === s).length, us = s => D.users.filter(x => (x.status || "active") === s).length;
    const income = D.feat.filter(f => f.status === "approved").reduce((s, f) => s + (f.amount || 0), 0), tot = p.listings + p.wanted + p.feat + p.reports;
    return `<div class="card"><h3>Requiere tu atención</h3>${tot ? `<div class="attn">${[["listings", "Publicaciones por aprobar"], ["wanted", "Pedidos por aprobar"], ["feat", "Destacados por revisar"], ["reports", "Denuncias sin revisar"]].filter(([k]) => p[k]).map(([k, l]) => `<button class="btn" data-tab="${k}">${l} <span class="n">${p[k]}</span></button>`).join("")}</div>` : '<span class="allgood">✓ Todo al día.</span>'}</div>
    <div class="grid kpis" style="margin-bottom:14px">
      ${kpi("👥", "Usuarios registrados", D.users.length - us("deleted"), `${us("active")} activos · ${us("suspended")} suspendidos · ${us("deleted")} eliminados`, "users")}
      ${kpi("👀", "Visitantes sin registro", D.vAnon, `${D.vTot} dispositivos en total (aprox.)`, "visitors")}
      ${kpi("🛍️", "Publicaciones", D.listings.length, `${lc("approved")} activas · ${lc("pending")} pendientes · ${lc("expired")} vencidas · ${lc("rejected")} rechazadas`, "listings")}
      ${kpi("⭐", "Destacadas activas", D.listings.filter(isFeat).length, `${D.feat.length} solicitudes en total`, "feat")}
      ${kpi("🔎", "Busco comprar", D.wanted.length, `${D.wanted.filter(x => lst(x) === "approved").length} activos · ${p.wanted} pendientes`, "wanted")}
      ${kpi("💬", "Comentarios y respuestas", D.comments.length + D.replies.length, `${D.comments.length} comentarios · ${D.replies.length} respuestas`, "comments")}
      ${kpi("⚑", "Denuncias", D.reports.length, `${p.reports} sin revisar`, "reports")}
      ${kpi("💰", "Destacados cobrados", gs(income), "Suma de solicitudes aprobadas")}
      ${kpi("👁️", "Visitas a anuncios", D.listings.reduce((s, x) => s + (x.views || 0), 0), "Suma de todas las publicaciones")}
    </div>
    <div class="grid two">${cc("Usuarios nuevos", daily(D.users, "createdAt"))}${cc("Publicaciones nuevas", daily(D.listings, "createdAt"))}${cc("Visitantes nuevos", daily(D.vis, "firstSeen"))}${cc("Pedidos “Busco comprar”", daily(D.wanted, "createdAt"))}</div>
    <div class="grid two"><div class="card"><h3>Publicaciones por categoría</h3>${hb(top(D.listings, "category", 10))}</div><div class="card"><h3>Ciudades con más publicaciones</h3>${hb(top(D.listings, "city"))}</div></div>
    <div class="card"><h3>Vendedores más activos</h3>${hb(top(D.listings, "sellerName"))}</div>`;
  },
  visitors() {
    const rec = [...D.vis].sort((a, b) => ms(b.lastSeen) - ms(a.lastSeen)).slice(0, 30);
    return `<div class="grid kpis" style="margin-bottom:14px">${kpi("👀", "Sin registro", D.vAnon, "Navegadores que no iniciaron sesión")}${kpi("✅", "Se registraron", D.vTot - D.vAnon, "Visitantes convertidos en usuarios")}${kpi("📱", "Total dispositivos", D.vTot, "Contador aproximado por navegador")}${kpi("🆕", "Nuevos (30 días)", D.vis.length, "Primera visita en el último mes")}</div>
    <div class="grid two">${cc("Visitantes nuevos por día", daily(D.vis, "firstSeen"))}${cc("Registros por día", daily(D.users, "createdAt"))}</div>
    <div class="card"><h3>Últimos visitantes</h3><div class="scroll-x"><table class="tbl"><tr><th>ID (parcial)</th><th>Primera visita</th><th>Última visita</th><th>Estado</th></tr>${rec.map(v => `<tr><td><span class="mono">${esc(v.id.slice(0, 8))}</span></td><td>${dt(v.firstSeen)}</td><td>${dt(v.lastSeen)}</td><td>${v.converted ? "Se registró" : "Anónimo"}</td></tr>`).join("") || '<tr><td colspan="4">Sin datos.</td></tr>'}</table></div><p class="muted">Se cuentan navegadores, no personas: una persona con dos dispositivos cuenta dos veces. No se guardan datos personales.</p></div>`;
  },
  logs() { return `<div class="card"><div class="scroll-x"><table class="tbl"><tr><th>Fecha</th><th>Administrador</th><th>Acción</th><th>Detalle</th></tr>${ord(D.logs.map(l => ({ ...l, createdAt: l.at }))).slice(0, 300).map(l => `<tr><td>${dt(l.at)}</td><td>${esc(l.admin)}</td><td>${esc(l.action)}</td><td>${esc(l.target)}</td></tr>`).join("") || '<tr><td colspan="4">Todavía no hay acciones registradas.</td></tr>'}</table></div></div>`; },
  settings() {
    const ex = [["listings", "Publicaciones"], ["wanted", "Busco comprar"], ["destacados", "Destacados"], ["comentarios", "Comentarios y respuestas"], ["denuncias", "Denuncias"], ["users", "Usuarios"], ["actividad", "Actividad del panel"]];
    return `<div class="card"><h3>Exportar datos (CSV, abre en Excel)</h3><div class="attn">${ex.map(([k, l]) => `<button class="btn" data-exp="${k}">⬇ ${l}</button>`).join("")}</div></div>
    <div class="card"><h3>Administradores</h3>${D.admins.map(a => `<div class="mini"><span>${esc(UN(a.id))}<br><small class="mono">${esc(a.id)}</small></span></div>`).join("") || '<p class="muted">—</p>'}<p class="muted">Para sumar un administrador: Firebase Console → Firestore → colección <code>admins</code> → documento con el UID de esa persona (lo ve al entrar a este panel). Para quitarlo, borrá ese documento.</p></div>
    <div class="card"><h3>Notas</h3><p class="muted">• Eliminar datos de un integrante borra su perfil, anuncios, pedidos, comentarios, fotos y comprobantes, y bloquea su acceso. La cuenta de Google/Facebook en Firebase Authentication se elimina aparte desde Firebase Console → Authentication.<br>• El panel carga todos los registros en el navegador: ideal para miles de registros; si crece mucho conviene paginar en servidor.</p></div>`;
  }
};

/* ---------- Detalle (modal) ---------- */
const kv = (l, v) => `<div class="kv"><span>${l}</span>${v || "—"}</div>`;
const dlg = $("#modal");
function openModal(k) {
  const [t, id] = [k.slice(0, 1), k.slice(2)]; let h = "";
  if (t === "L") {
    const x = L(id); if (!x.id) { dlg.open && dlg.close(); return; }
    const cs = D.comments.filter(c => c.parent === id);
    h = `${x.photo ? `<img class="m-photo" src="${esc(x.photo)}" alt="">` : ""}<h2>${esc(x.title)} ${bd(lst(x))}${isFeat(x) ? '<span class="badge feat">⭐ DESTACADA</span>' : ""}</h2>
    <div class="kvs">${kv("Precio", gs(x.price))}${kv("Categoría", esc(x.category))}${kv("Ubicación", esc(x.city + ", " + x.department))}${kv("Vendedor", `<a href="#" data-open="U:${esc(x.ownerUid)}">${esc(x.sellerName)}</a>`)}${kv("WhatsApp", `<a href="${wa(x.whatsapp)}" target="_blank" rel="noopener">${esc(x.whatsapp)}</a>`)}${kv("Creada", dt(x.createdAt))}${kv("Aprobada", dt(x.approvedAt))}${kv("Vence", dt(x.expiresAt))}${kv("Destacada hasta", isFeat(x) ? dt(x.featuredUntil) : "")}${kv("Visitas", x.views || 0)}${kv("Denuncias", D.reports.filter(r => r.listingId === id).length)}${kv("Motivo de rechazo", esc(x.rejectReason))}</div>
    <h3>Descripción</h3><div class="desc">${esc(x.description)}</div>
    <h3>Comentarios (${cs.length})</h3>${cs.map(c => `<div class="mini"><span><b>${esc(c.author)}</b> · <small>${dt(c.createdAt)}</small><br>${esc(c.text)}</span>${btn("C:del", c.id, "🗑", "bad", "¿Eliminar comentario?", c.path)}</div>`).join("") || '<p class="muted">Sin comentarios.</p>'}
    <div class="actions">${lst(x) !== "approved" ? btn("L:approve", id, "✓ Aprobar", "ok") : ""}${lst(x) === "pending" ? btn("L:reject", id, "✕ Rechazar", "warn") : ""}${["approved", "expired"].includes(lst(x)) ? btn("L:feat", id, "⭐ Destacar", "warn") + btn("L:ext", id, "＋ Extender vencimiento") : ""}${isFeat(x) ? btn("L:unfeat", id, "Quitar destacado") : ""}${x.status === "approved" ? `<a class="btn" href="index.html#l=${esc(id)}" target="_blank">Ver en el sitio ↗</a>` : ""}${btn("L:del", id, "🗑 Eliminar", "bad", "¿Eliminar definitivamente esta publicación, su foto y sus comentarios?")}</div>`;
  } else if (t === "W") {
    const x = W(id); if (!x.id) { dlg.open && dlg.close(); return; }
    const rs = D.replies.filter(r => r.parent === id);
    h = `<h2>🔎 ${esc(x.title)} ${bd(lst(x))}</h2>${x.photo ? `<img class="m-photo" src="${esc(x.photo)}" alt="">` : ""}<div class="kvs">${kv("Comprador", `<a href="#" data-open="U:${esc(x.uid)}">${esc(x.author)}</a>`)}${kv("WhatsApp", `<a href="${wa(x.whatsapp)}" target="_blank" rel="noopener">${esc(x.whatsapp)}</a>`)}${kv("Ubicación", esc(x.city + ", " + x.department))}${kv("Creado", dt(x.createdAt))}${kv("Vence", dt(x.expiresAt))}${kv("Motivo de rechazo", esc(x.rejectReason))}</div><h3>Detalle</h3><div class="desc">${esc(x.details)}</div>
    <h3>Respuestas de vendedores (${rs.length})</h3>${rs.map(r => `<div class="mini"><span><b>${esc(r.author)}</b> · <small>${dt(r.createdAt)}</small><br>${esc(r.text)}${r.photo ? `<a href="${esc(r.photo)}" target="_blank" rel="noopener"><img class="reply-photo" src="${esc(r.photo)}" alt=""></a>` : ""}</span>${btn("C:del", r.id, "🗑", "bad", "¿Eliminar respuesta?", r.path)}</div>`).join("") || '<p class="muted">Sin respuestas.</p>'}<div class="actions">${wActs(x)}</div>`;
  } else if (t === "U") {
    const x = U(id); if (!x.id) { dlg.open && dlg.close(); return; } const s = x.status || "active", ls = D.listings.filter(l => l.ownerUid === id), mine = id === me.uid;
    h = `<h2>${img(x.photo, "avatar")} ${esc(x.name)} ${bd(s)}</h2><div class="kvs">${kv("Email", esc(x.email))}${kv("WhatsApp", x.whatsapp ? `<a href="${wa(x.whatsapp)}" target="_blank" rel="noopener">${esc(x.whatsapp)}</a>` : "")}${kv("Ciudad", esc(x.city))}${kv("Registro", dt(x.createdAt))}${kv("UID", `<span class="mono">${esc(id)}</span>`)}${kv("Pedidos “Busco comprar”", D.wanted.filter(w => w.uid === id).length)}${kv("Comentarios y respuestas", [...D.comments, ...D.replies].filter(c => c.uid === id).length)}${kv("Denuncias enviadas", D.reports.filter(r => r.uid === id).length)}</div>
    <h3>Publicaciones (${ls.length})</h3>${ls.map(l => `<div class="mini"><span>${esc(l.title)} ${bd(lst(l))}</span>${open("L:" + l.id)}</div>`).join("") || '<p class="muted">Sin publicaciones.</p>'}
    <div class="actions">${!mine && s !== "deleted" ? btn("U:sus", id, s === "suspended" ? "Reactivar" : "Suspender", s === "suspended" ? "ok" : "warn") + btn("U:del", id, "🗑 Eliminar datos", "bad", "¿Eliminar al integrante y TODOS sus datos? No se puede deshacer.") : ""}</div>`;
  }
  S.modal = k; $("#modalBody").innerHTML = h; if (!dlg.open) dlg.showModal();
}
$("#modalClose").onclick = () => dlg.close();
dlg.addEventListener("click", e => { if (e.target === dlg) dlg.close(); });
dlg.addEventListener("close", () => S.modal = null);

/* ---------- Acciones ---------- */
const ex = (c, i, d) => updateDoc(doc(db, c, i), d);
const rm = async u => { if (!u) return; try { await deleteObject(ref(st, u)); } catch (e) { if (e.code !== "storage/object-not-found") console.warn(e); } };
const feature = (id, d) => { if (!L(id).id) throw new Error("La publicación ya no existe."); return ex("listings", id, { featured: true, featuredUntil: new Date(Date.now() + d * DAY), expiresAt: new Date(Math.max(ms(L(id).expiresAt), Date.now() + 30 * DAY)), status: "approved" }); };
const delListing = async l => { await rm(l.photo); for (const c of D.comments.filter(c => c.parent === l.id)) await deleteDoc(doc(db, c.path)); await deleteDoc(doc(db, "listings", l.id)); };
const delWanted = async w => { await rm(w.photo); for (const r of D.replies.filter(r => r.parent === w.id)) { await rm(r.photo); await deleteDoc(doc(db, r.path)); } await deleteDoc(doc(db, "wantedRequests", w.id)); };
async function delUser(u) {
  for (const l of D.listings.filter(l => l.ownerUid === u.id)) await delListing(l);
  for (const w of D.wanted.filter(w => w.uid === u.id)) await delWanted(w);
  for (const c of D.comments.filter(c => c.uid === u.id)) await deleteDoc(doc(db, c.path));
  for (const r of D.replies.filter(r => r.uid === u.id)) { await rm(r.photo); await deleteDoc(doc(db, r.path)); }
  for (const f of D.feat.filter(f => f.uid === u.id)) { await rm(f.receipt); await deleteDoc(doc(db, "featuredRequests", f.id)); }
  for (const r of D.reports.filter(r => r.uid === u.id)) await deleteDoc(doc(db, "listingReports", r.id));
  for (const p of ["profiles", "listings", "wanted", "wanted-replies", "receipts"]) { try { for (const i of (await listAll(ref(st, p + "/" + u.id))).items) await deleteObject(i); } catch (e) { console.warn(p, e); } }
  await ex("users", u.id, { status: "deleted", name: "Cuenta eliminada", photo: "", whatsapp: "", city: "", email: "", deletedAt: serverTimestamp() });
}
const ask = (m, d) => { const r = prompt(m, d); return r === null ? null : r.trim(); };
const H = {
  "L:approve": async id => { await ex("listings", id, { status: "approved", approvedAt: serverTimestamp(), expiresAt: new Date(Date.now() + 10 * DAY), rejectReason: "" }); return ["Aprobó publicación", LT(id)]; },
  "L:reject": async id => { const r = ask("Motivo del rechazo (lo verá el usuario):"); if (r === null) return; await ex("listings", id, { status: "rejected", rejectReason: r.slice(0, 200) }); return ["Rechazó publicación", LT(id)]; },
  "L:feat": async id => { const d = Number(ask("¿Cuántos días destacada? (1 a 90)", "10")); if (!(d > 0 && d <= 90)) return; await feature(id, d); return ["Destacó publicación", `${LT(id)} (${d} días)`]; },
  "L:unfeat": async id => { await ex("listings", id, { featured: false, featuredUntil: null }); return ["Quitó destacado", LT(id)]; },
  "L:ext": async id => { const d = Number(ask("¿Cuántos días extender el vencimiento?", "10")); if (!(d > 0 && d <= 365)) return; await ex("listings", id, { expiresAt: new Date(Math.max(Date.now(), ms(L(id).expiresAt)) + d * DAY) }); return ["Extendió vencimiento", `${LT(id)} (+${d} días)`]; },
  "L:del": async id => { const t = LT(id); await delListing(L(id)); dlg.open && dlg.close(); return ["Eliminó publicación", t]; },
  "W:approve": async id => { await ex("wantedRequests", id, { status: "approved", approvedAt: serverTimestamp(), expiresAt: new Date(Date.now() + 10 * DAY), rejectReason: "" }); return ["Aprobó pedido", W(id).title]; },
  "W:reject": async id => { const r = ask("Motivo del rechazo:"); if (r === null) return; await ex("wantedRequests", id, { status: "rejected", rejectReason: r.slice(0, 200) }); return ["Rechazó pedido", W(id).title]; },
  "W:del": async id => { const t = W(id).title; await delWanted(W(id)); dlg.open && dlg.close(); return ["Eliminó pedido", t]; },
  "F:ok": async id => { const r = F(id), P = { 30: 30000, 20: 20000, 10: 10000, 3: 5000 }; if (P[r.duration] !== r.amount) throw new Error("La solicitud tiene datos de pago no válidos."); await feature(r.listingId, r.duration); await ex("featuredRequests", id, { status: "approved", approvedAt: serverTimestamp() }); return ["Aprobó destacado", `${LT(r.listingId)} (${r.duration} días)`]; },
  "F:no": async id => { const r = ask("Motivo del rechazo:"); if (r === null) return; await ex("featuredRequests", id, { status: "rejected", rejectReason: r.slice(0, 200), reviewedAt: serverTimestamp() }); return ["Rechazó destacado", LT(F(id).listingId)]; },
  "C:del": async (id, path) => { await deleteDoc(doc(db, path)); return ["Eliminó mensaje", path.split("/").slice(-3, -2)[0]]; },
  "R:ok": async id => { await ex("listingReports", id, { status: "reviewed", reviewedAt: serverTimestamp() }); return ["Marcó denuncia revisada", LT(D.reports.find(r => r.id === id)?.listingId)]; },
  "R:dellisting": async id => { const r = D.reports.find(r => r.id === id), l = L(r.listingId); await delListing(l); await ex("listingReports", id, { status: "reviewed", reviewedAt: serverTimestamp() }); return ["Eliminó publicación denunciada", l.title]; },
  "R:sus": async id => { const o = L(D.reports.find(r => r.id === id).listingId).ownerUid; if (!o || o === me.uid) throw new Error("No se puede suspender a este usuario."); await ex("users", o, { status: "suspended" }); return ["Suspendió usuario", UN(o)]; },
  "U:sus": async id => { const s = (U(id).status || "active") === "suspended" ? "active" : "suspended"; await ex("users", id, { status: s }); return [s === "active" ? "Reactivó usuario" : "Suspendió usuario", UN(id)]; },
  "U:del": async id => { if (id === me.uid) throw new Error("No podés eliminar tu propia cuenta."); const n = UN(id); await delUser(U(id)); return ["Eliminó datos de usuario", n]; }
};
const log = (action, target) => addDoc(collection(db, "adminLogs"), { admin: me.displayName || me.email || me.uid, uid: me.uid, action, target: String(target || ""), at: serverTimestamp() }).catch(console.warn);

document.addEventListener("click", async e => {
  const t = e.target.closest("[data-tab]"); if (t) return go(t.dataset.tab);
  const o = e.target.closest("[data-open]"); if (o) { e.preventDefault(); return openModal(o.dataset.open); }
  const x = e.target.closest("[data-exp]"); if (x) return csv(x.dataset.exp);
  if (e.target.closest("[data-more]")) { S.n += PAGE; return fill(); }
  const b = e.target.closest("[data-a]"); if (!b) return;
  if (b.dataset.c && !confirm(b.dataset.c)) return;
  let r; busy(true);
  try { r = await H[b.dataset.a](b.dataset.id, b.dataset.path); if (r) { await log(...r); toast("Listo ✓"); } }
  catch (err) { console.error(err); toast(err.message, true); }
  busy(false); if (r) await load();
});

/* ---------- Exportar CSV ---------- */
function csv(name) {
  const rows = ({ listings: D.listings, wanted: D.wanted, destacados: D.feat, comentarios: [...D.comments.map(c => ({ ...c, tipo: "comentario" })), ...D.replies.map(c => ({ ...c, tipo: "respuesta" }))], denuncias: D.reports, users: D.users, actividad: D.logs, feat: D.feat, comments: [...D.comments, ...D.replies], reports: D.reports })[name] || [];
  if (!rows.length) return toast("No hay datos para exportar.", true);
  const cols = [...new Set(rows.flatMap(Object.keys))], cell = v => { if (v?.toMillis) v = new Date(v.toMillis()).toISOString(); else if (v && typeof v === "object") v = JSON.stringify(v); return '"' + String(v ?? "").replace(/"/g, '""') + '"'; };
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob(["\ufeff" + [cols.join(","), ...rows.map(r => cols.map(c => cell(r[c])).join(","))].join("\n")], { type: "text/csv;charset=utf-8" }));
  a.download = `san-pedro-${name}-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
}
